﻿namespace BBMS
{
    partial class Patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.savebtn = new Guna.UI2.WinForms.Guna2Button();
            this.addressbox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.bgbox = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.phonebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.genderbox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.agebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.namebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.donatelabel = new System.Windows.Forms.Label();
            this.logoutlabel = new System.Windows.Forms.Label();
            this.bloodtransferlabel = new System.Windows.Forms.Label();
            this.bloodstocklabel = new System.Windows.Forms.Label();
            this.viewpatientlabel = new System.Windows.Forms.Label();
            this.patientlabel = new System.Windows.Forms.Label();
            this.viewdonorslabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.donorlabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // savebtn
            // 
            this.savebtn.AutoRoundedCorners = true;
            this.savebtn.BorderRadius = 17;
            this.savebtn.CheckedState.Parent = this.savebtn;
            this.savebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.savebtn.CustomImages.Parent = this.savebtn;
            this.savebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savebtn.DisabledState.Parent = this.savebtn;
            this.savebtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.savebtn.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebtn.ForeColor = System.Drawing.Color.White;
            this.savebtn.HoverState.Parent = this.savebtn;
            this.savebtn.Location = new System.Drawing.Point(584, 549);
            this.savebtn.Margin = new System.Windows.Forms.Padding(2);
            this.savebtn.Name = "savebtn";
            this.savebtn.ShadowDecoration.Parent = this.savebtn;
            this.savebtn.Size = new System.Drawing.Size(144, 37);
            this.savebtn.TabIndex = 45;
            this.savebtn.Text = "Save";
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // addressbox
            // 
            this.addressbox.Location = new System.Drawing.Point(594, 402);
            this.addressbox.Margin = new System.Windows.Forms.Padding(2);
            this.addressbox.Multiline = true;
            this.addressbox.Name = "addressbox";
            this.addressbox.Size = new System.Drawing.Size(151, 84);
            this.addressbox.TabIndex = 44;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(594, 358);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 22);
            this.label16.TabIndex = 43;
            this.label16.Text = "Address";
            // 
            // bgbox
            // 
            this.bgbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.bgbox.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bgbox.FormattingEnabled = true;
            this.bgbox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.bgbox.Location = new System.Drawing.Point(829, 344);
            this.bgbox.Margin = new System.Windows.Forms.Padding(2);
            this.bgbox.Name = "bgbox";
            this.bgbox.Size = new System.Drawing.Size(159, 23);
            this.bgbox.TabIndex = 42;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(825, 297);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(137, 22);
            this.label15.TabIndex = 41;
            this.label15.Text = "Blood Group ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(329, 295);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 22);
            this.label14.TabIndex = 40;
            this.label14.Text = "Phone No";
            // 
            // phonebox
            // 
            this.phonebox.AutoRoundedCorners = true;
            this.phonebox.BorderColor = System.Drawing.Color.Red;
            this.phonebox.BorderRadius = 13;
            this.phonebox.BorderThickness = 2;
            this.phonebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phonebox.DefaultText = "";
            this.phonebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.phonebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.phonebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phonebox.DisabledState.Parent = this.phonebox;
            this.phonebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phonebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phonebox.FocusedState.Parent = this.phonebox;
            this.phonebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.phonebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phonebox.HoverState.Parent = this.phonebox;
            this.phonebox.Location = new System.Drawing.Point(329, 343);
            this.phonebox.Margin = new System.Windows.Forms.Padding(2);
            this.phonebox.Name = "phonebox";
            this.phonebox.PasswordChar = '\0';
            this.phonebox.PlaceholderText = "";
            this.phonebox.SelectedText = "";
            this.phonebox.ShadowDecoration.Parent = this.phonebox;
            this.phonebox.Size = new System.Drawing.Size(150, 29);
            this.phonebox.TabIndex = 39;
            // 
            // genderbox
            // 
            this.genderbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.genderbox.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderbox.FormattingEnabled = true;
            this.genderbox.Items.AddRange(new object[] {
            "Male ",
            "Female",
            "Others"});
            this.genderbox.Location = new System.Drawing.Point(844, 211);
            this.genderbox.Margin = new System.Windows.Forms.Padding(2);
            this.genderbox.Name = "genderbox";
            this.genderbox.Size = new System.Drawing.Size(159, 23);
            this.genderbox.TabIndex = 38;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(848, 162);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 22);
            this.label13.TabIndex = 37;
            this.label13.Text = "Gender";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(594, 159);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 22);
            this.label12.TabIndex = 36;
            this.label12.Text = "Age";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(329, 159);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 22);
            this.label11.TabIndex = 35;
            this.label11.Text = "Name";
            // 
            // agebox
            // 
            this.agebox.AutoRoundedCorners = true;
            this.agebox.BorderColor = System.Drawing.Color.Red;
            this.agebox.BorderRadius = 13;
            this.agebox.BorderThickness = 2;
            this.agebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.agebox.DefaultText = "";
            this.agebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.agebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.agebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.agebox.DisabledState.Parent = this.agebox;
            this.agebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.agebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.agebox.FocusedState.Parent = this.agebox;
            this.agebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.agebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.agebox.HoverState.Parent = this.agebox;
            this.agebox.Location = new System.Drawing.Point(594, 207);
            this.agebox.Margin = new System.Windows.Forms.Padding(2);
            this.agebox.Name = "agebox";
            this.agebox.PasswordChar = '\0';
            this.agebox.PlaceholderText = "";
            this.agebox.SelectedText = "";
            this.agebox.ShadowDecoration.Parent = this.agebox;
            this.agebox.Size = new System.Drawing.Size(150, 29);
            this.agebox.TabIndex = 34;
            // 
            // namebox
            // 
            this.namebox.AutoRoundedCorners = true;
            this.namebox.BorderColor = System.Drawing.Color.Red;
            this.namebox.BorderRadius = 13;
            this.namebox.BorderThickness = 2;
            this.namebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namebox.DefaultText = "";
            this.namebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.namebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.namebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.DisabledState.Parent = this.namebox;
            this.namebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.FocusedState.Parent = this.namebox;
            this.namebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.namebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.HoverState.Parent = this.namebox;
            this.namebox.Location = new System.Drawing.Point(329, 207);
            this.namebox.Margin = new System.Windows.Forms.Padding(2);
            this.namebox.Name = "namebox";
            this.namebox.PasswordChar = '\0';
            this.namebox.PlaceholderText = "";
            this.namebox.SelectedText = "";
            this.namebox.ShadowDecoration.Parent = this.namebox;
            this.namebox.Size = new System.Drawing.Size(150, 29);
            this.namebox.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(623, 76);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 25);
            this.label10.TabIndex = 46;
            this.label10.Text = "Patient";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.donatelabel);
            this.panel1.Controls.Add(this.logoutlabel);
            this.panel1.Controls.Add(this.bloodtransferlabel);
            this.panel1.Controls.Add(this.bloodstocklabel);
            this.panel1.Controls.Add(this.viewpatientlabel);
            this.panel1.Controls.Add(this.patientlabel);
            this.panel1.Controls.Add(this.viewdonorslabel);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.donorlabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.ForeColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 640);
            this.panel1.TabIndex = 47;
            // 
            // donatelabel
            // 
            this.donatelabel.AutoSize = true;
            this.donatelabel.BackColor = System.Drawing.Color.Transparent;
            this.donatelabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donatelabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donatelabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donatelabel.Location = new System.Drawing.Point(38, 232);
            this.donatelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donatelabel.Name = "donatelabel";
            this.donatelabel.Size = new System.Drawing.Size(90, 25);
            this.donatelabel.TabIndex = 16;
            this.donatelabel.Text = "Donate";
            this.donatelabel.Click += new System.EventHandler(this.donatelabel_Click_1);
            // 
            // logoutlabel
            // 
            this.logoutlabel.AutoSize = true;
            this.logoutlabel.BackColor = System.Drawing.Color.Transparent;
            this.logoutlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.logoutlabel.Location = new System.Drawing.Point(59, 605);
            this.logoutlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.logoutlabel.Name = "logoutlabel";
            this.logoutlabel.Size = new System.Drawing.Size(96, 25);
            this.logoutlabel.TabIndex = 15;
            this.logoutlabel.Text = "Log out";
            this.logoutlabel.Click += new System.EventHandler(this.logoutlabel_Click);
            // 
            // bloodtransferlabel
            // 
            this.bloodtransferlabel.AutoSize = true;
            this.bloodtransferlabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodtransferlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodtransferlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodtransferlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodtransferlabel.Location = new System.Drawing.Point(39, 450);
            this.bloodtransferlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodtransferlabel.Name = "bloodtransferlabel";
            this.bloodtransferlabel.Size = new System.Drawing.Size(177, 25);
            this.bloodtransferlabel.TabIndex = 12;
            this.bloodtransferlabel.Text = "Blood Transfer";
            this.bloodtransferlabel.Click += new System.EventHandler(this.bloodtransferlabel_Click);
            // 
            // bloodstocklabel
            // 
            this.bloodstocklabel.AutoSize = true;
            this.bloodstocklabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodstocklabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodstocklabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodstocklabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodstocklabel.Location = new System.Drawing.Point(39, 397);
            this.bloodstocklabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodstocklabel.Name = "bloodstocklabel";
            this.bloodstocklabel.Size = new System.Drawing.Size(143, 25);
            this.bloodstocklabel.TabIndex = 10;
            this.bloodstocklabel.Text = "Blood Stock";
            this.bloodstocklabel.Click += new System.EventHandler(this.bloodstocklabel_Click);
            // 
            // viewpatientlabel
            // 
            this.viewpatientlabel.AutoSize = true;
            this.viewpatientlabel.BackColor = System.Drawing.Color.Transparent;
            this.viewpatientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewpatientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewpatientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewpatientlabel.Location = new System.Drawing.Point(39, 343);
            this.viewpatientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewpatientlabel.Name = "viewpatientlabel";
            this.viewpatientlabel.Size = new System.Drawing.Size(147, 25);
            this.viewpatientlabel.TabIndex = 8;
            this.viewpatientlabel.Text = "View Patient";
            this.viewpatientlabel.Click += new System.EventHandler(this.viewpatientlabel_Click);
            // 
            // patientlabel
            // 
            this.patientlabel.AutoSize = true;
            this.patientlabel.BackColor = System.Drawing.Color.Transparent;
            this.patientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.patientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.patientlabel.Location = new System.Drawing.Point(39, 288);
            this.patientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.patientlabel.Name = "patientlabel";
            this.patientlabel.Size = new System.Drawing.Size(88, 25);
            this.patientlabel.TabIndex = 6;
            this.patientlabel.Text = "Patient";
            // 
            // viewdonorslabel
            // 
            this.viewdonorslabel.AutoSize = true;
            this.viewdonorslabel.BackColor = System.Drawing.Color.Transparent;
            this.viewdonorslabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewdonorslabel.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewdonorslabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewdonorslabel.Location = new System.Drawing.Point(39, 180);
            this.viewdonorslabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewdonorslabel.Name = "viewdonorslabel";
            this.viewdonorslabel.Size = new System.Drawing.Size(140, 23);
            this.viewdonorslabel.TabIndex = 5;
            this.viewdonorslabel.Text = "View Donors";
            this.viewdonorslabel.Click += new System.EventHandler(this.viewdonorslabel_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.AliceBlue;
            this.panel3.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel3.Location = new System.Drawing.Point(25, 278);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(8, 40);
            this.panel3.TabIndex = 4;
            // 
            // donorlabel
            // 
            this.donorlabel.AutoSize = true;
            this.donorlabel.BackColor = System.Drawing.Color.Transparent;
            this.donorlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donorlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donorlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donorlabel.Location = new System.Drawing.Point(39, 126);
            this.donorlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donorlabel.Name = "donorlabel";
            this.donorlabel.Size = new System.Drawing.Size(81, 25);
            this.donorlabel.TabIndex = 3;
            this.donorlabel.Text = "Donor";
            this.donorlabel.Click += new System.EventHandler(this.donorlabel_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(222, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(818, 49);
            this.panel2.TabIndex = 49;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(280, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Blood Bank Management System";
            // 
            // Patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.savebtn);
            this.Controls.Add(this.addressbox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.bgbox);
            this.Controls.Add(this.namebox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.agebox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.phonebox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.genderbox);
            this.Controls.Add(this.label13);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Patient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Patient";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button savebtn;
        private System.Windows.Forms.TextBox addressbox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox bgbox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2TextBox phonebox;
        private System.Windows.Forms.ComboBox genderbox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2TextBox agebox;
        private Guna.UI2.WinForms.Guna2TextBox namebox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label donatelabel;
        private System.Windows.Forms.Label logoutlabel;
        private System.Windows.Forms.Label bloodtransferlabel;
        private System.Windows.Forms.Label bloodstocklabel;
        private System.Windows.Forms.Label viewpatientlabel;
        private System.Windows.Forms.Label patientlabel;
        private System.Windows.Forms.Label viewdonorslabel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label donorlabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;

    }
}