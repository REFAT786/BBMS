﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Donate : Form
    {
        int oldstock, stock;
        SqlConnection conn;
        public Donate()
        {
            stock = 1;
            InitializeComponent();
        }

        private void donorlabel_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();

        }
        private void viewdonorslabel_Click(object sender, EventArgs e)
        {
            View_Donors vd = new View_Donors();
            vd.Show();
            this.Hide();

        }
       

        private void patientlabel_Click(object sender, EventArgs e)
        {
            Patient pa = new Patient();
            pa.Show();
            this.Hide();
        }
        private void viewpatientlabel_Click(object sender, EventArgs e)
        {
            View_Patients vp = new View_Patients();
            vp.Show();
            this.Hide();

        }



        private void bloodstocklabel_Click(object sender, EventArgs e)
        {
            Blood_Stock bs = new Blood_Stock();
            bs.Show();
            this.Hide();
        }

        private void bloodtransferlabel_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();

        }

      

        private void logoutlabel_Click(object sender, EventArgs e)
        {
            Login L = new Login();
            L.Show();
            this.Hide();
        }

        private void GetStock(string bgbox)//for 1st stock  
        {

            conn = new SqlConnection(
            @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

            conn.Open();

            string query = "select Blood,Stock from StockTB where Blood='" + bgbox + "'";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                oldstock = Convert.ToInt32(dr["Stock"].ToString());

            }

        }

        private void BStock()//for update stock
        {

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();
                GetStock(bgbox.Text);
                stock = oldstock - 1;
                string query = "update StockTB set  Stock='" + stock + "' where Blood='" + bgbox.Text + "'  ";

                SqlCommand cmd = new SqlCommand(query, conn);
                int row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    // MessageBox.Show("update successful");
                    query = "select Blood,Stock from StockTB ";

                    cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];
                    DataGridView2.DataSource = dt;
                    DataGridView2.Refresh();


                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }


        }
        private void BloodStock()//show blood group and stock
        {
            try
            {
                conn = new SqlConnection(
               @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();

                string query = "select Blood,Stock from StockTB ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                DataGridView2.DataSource = dt;
                DataGridView2.Refresh();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }

        private void donatebtn_Click(object sender, EventArgs e)
        {
            if (idbox.Text == "")
            {
                MessageBox.Show("please select a row first");

            }
            else
            {
                try
                {
                    conn = new SqlConnection(
                    @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    string query = "delete from DonorTB where Id= " + idbox.Text;
                    SqlCommand cmd = new SqlCommand(query, conn);
                    int row = cmd.ExecuteNonQuery();

                    if (row > 0)
                    {
                        MessageBox.Show("Donate successful");
                         query = "select Id,Name,Age,Gender,Phone,Blood,Address from DonorTB ";

                         cmd = new SqlCommand(query, conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        DataTable dt = ds.Tables[0];
                        DataGridView1.DataSource = dt;
                        DataGridView1.Refresh();

                        BStock();

                        idbox.Text = "";
                        namebox.Text = "";
                        bgbox.Text = null;
                        


                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }

            }
        }

        private void Donate_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();

                string query = "select Id,Name,Age,Gender,Phone,Blood,Address from DonorTB ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                DataGridView1.DataSource = dt;
                DataGridView1.Refresh();

                BloodStock();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }


        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    conn = new SqlConnection(
                         @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    int dataid = Convert.ToInt32(DataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                    string query = "select * from DonorTB where Id='" + dataid + "' ";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];

                    idbox.Text = dt.Rows[0]["Id"].ToString(); ;
                    namebox.Text = dt.Rows[0]["Name"].ToString();
                    bgbox.Text = dt.Rows[0]["Blood"].ToString();




                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }

        
    }
}
