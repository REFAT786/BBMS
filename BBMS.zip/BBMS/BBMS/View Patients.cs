﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class View_Patients : Form
    {
        SqlConnection conn;
        public View_Patients()
        {
            InitializeComponent();
        }
        private void donorlabel_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();

        }
        private void viewdonorslabel_Click(object sender, EventArgs e)
        {
            View_Donors vd = new View_Donors();
            vd.Show();
            this.Hide();

        }
        private void donatelabel_Click(object sender, EventArgs e)
        {
            Donate donate = new Donate();
            donate.Show();
            this.Hide();
        }


        private void patientlabel_Click(object sender, EventArgs e)
        {
            Patient pa = new Patient();
            pa.Show();
            this.Hide();
        }

       

        private void bloodstocklabel_Click(object sender, EventArgs e)
        {
            Blood_Stock bs = new Blood_Stock();
            bs.Show();
            this.Hide();
        }

        private void bloodtransferlabel_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();

        }

        

        private void logoutlabel_Click(object sender, EventArgs e)
        {
            Login L = new Login();
            L.Show();
            this.Hide();
        }


        private void View_Patients_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();

                string query = "select Id,Name,Age,Gender,Phone,Blood,Address from PatientTB ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                DataGridView1.DataSource = dt;
                DataGridView1.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }


        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    conn = new SqlConnection(
                         @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    int dataid = Convert.ToInt32(DataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                    string query = "select * from PatientTB where Id='" + dataid + "' ";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];

                    idbox.Text = dt.Rows[0]["Id"].ToString(); 
                    namebox.Text = dt.Rows[0]["Name"].ToString();
                    agebox.Text = dt.Rows[0]["Age"].ToString();
                    genderbox.SelectedItem = dt.Rows[0]["Gender"].ToString();
                    phonebox.Text = dt.Rows[0]["Phone"].ToString();
                    addressbox.Text = dt.Rows[0]["Address"].ToString();
                    bgbox.Text = dt.Rows[0]["Blood"].ToString();




                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }

        }

        private void editbtn_Click(object sender, EventArgs e) 
        {

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();
                
                string query = "update PatientTB set  Name='" + namebox.Text + "',Age='"+agebox.Text+"',Gender='"+genderbox.SelectedItem.ToString()+"',Phone='"+phonebox.Text+"',Blood='"+bgbox.SelectedItem.ToString()+"',Address='"+addressbox.Text+"' where Id='" + idbox.Text + "'  ";

                SqlCommand cmd = new SqlCommand(query, conn);
                int row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    MessageBox.Show("update successful");
                    query = "select * from PatientTB ";

                    cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = ds.Tables[0];
                    DataGridView1.DataSource = dt;
                    DataGridView1.Refresh();

                    idbox.Text = "";
                    namebox.Text = "";
                    agebox.Text = "";
                    genderbox.SelectedItem = null;
                    phonebox.Text = "";
                    bgbox.Text = null;
                    addressbox.Text = "";


                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
                
            
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (idbox.Text == "")
            {
                MessageBox.Show("please select a row first");

            }
            else
            {
                try
                {
                    conn = new SqlConnection(
                    @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    string query = "delete from PatientTB where Id= " + idbox.Text;
                    SqlCommand cmd = new SqlCommand(query, conn);
                    int row=cmd.ExecuteNonQuery();

                    if (row > 0)
                    {
                        MessageBox.Show("Delete successful");
                        query = "select * from PatientTB ";

                        cmd = new SqlCommand(query, conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        DataTable dt = ds.Tables[0];
                        DataGridView1.DataSource = dt;
                        DataGridView1.Refresh();

                        idbox.Text = "";
                        namebox.Text = "";
                        agebox.Text = "";
                        genderbox.SelectedItem = null;
                        phonebox.Text = "";
                        bgbox.Text = null;
                        addressbox.Text = "";


                    }
               

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }

            }
        }


       
    }
}



/*
private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                conn.Open();
                
                string query = "select ID,Name,Location from users ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                //dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    int dataid = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                    conn = new SqlConnection(
                        @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                    conn.Open();

                    string query = "select * from users where ID= " + dataid;

                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];
                    idbox.Text = dt.Rows[0]["ID"].ToString();
                    namebox.Text = dt.Rows[0]["Name"].ToString();
                    locationbox.Text = dt.Rows[0]["Location"].ToString();


                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }

                
            
            
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (idbox.Text == "")
            {

                MessageBox.Show("please select a row first");
            }
            else
            {

                try
                {
                    conn = new SqlConnection(
                    @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                    conn.Open();

                    string query = "update users set  Name='" + namebox.Text + "' ,Location='" + locationbox.Text + "' where ID='" + idbox.Text + "'  ";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    int row = cmd.ExecuteNonQuery();

                    if (row > 0)
                    {
                        MessageBox.Show("update successful");
                        query = "select ID,Name,Location from users ";

                        cmd = new SqlCommand(query, conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        DataTable dt = ds.Tables[0];
                        dataGridView1.DataSource = dt;
                        dataGridView1.Refresh();

                        idbox.Text = "";
                        namebox.Text = "";
                        locationbox.Text = "";


                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }

            }
            
        }

        private void insertbtn_Click(object sender, EventArgs e)
        {
          
                string name, location, gender = "";
            name = namebox.Text;
            location = locationbox.Text;
            if (malebtn.Checked)
            {
                gender = "Male";

            }
            else if (femalebtn.Checked)
            {
                gender = "Female";
            }
            else if (otherbtn.Checked)
            {
                gender = "Other";
            }
            else
            {
                gender = "";
            }

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                conn.Open();
                string query = "insert into users (Name,Location,Gender) values('" + name + "','" + location + "','" + gender + "')";

                //string query = "select * from users ";

                SqlCommand cmd = new SqlCommand(query, conn);
                int row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    MessageBox.Show(" insert successfully");
                    query = "select ID,Name,Location from users ";

                    cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];
                    dataGridView1.DataSource = dt;
                    dataGridView1.Refresh();

                    idbox.Text = "";
                    namebox.Text = "";
                    locationbox.Text = "";


                }
                   
                    


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
           
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (idbox.Text == "")
            {
                MessageBox.Show("please select a row first");

            }
            else {
                try
                {
                    conn = new SqlConnection(
                    @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                    conn.Open();

                    string query = "delete from users where ID= "+idbox.Text;

                    SqlCommand cmd = new SqlCommand(query, conn);
                    int row = cmd.ExecuteNonQuery();

                    if (row > 0)
                    {
                        MessageBox.Show("delete successful");
                        query = "select ID,Name,Location from users ";

                        cmd = new SqlCommand(query, conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        DataTable dt = ds.Tables[0];
                        dataGridView1.DataSource = dt;
                        dataGridView1.Refresh();

                        idbox.Text = "";
                        namebox.Text = "";
                        locationbox.Text = "";
                        searchbox.Text = "";


                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }
            
            }
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            if (searchbox.Text == "")
            {

                MessageBox.Show("nothing to search ");
            }
            else
            {
                try
                {
                    conn = new SqlConnection(
                    @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                    conn.Open();

                    string query = "select * from users where name  like '%" + searchbox.Text + "%'";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();

                  
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        DataTable dt = ds.Tables[0];
                        dataGridView1.DataSource = dt;
                        dataGridView1.Refresh();





                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }
            }
        }

        private void refreshbtn_Click(object sender, EventArgs e)
        {

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=DataFormPrectice;Integrated Security=True");

                conn.Open();

                string query = "select * from users";

                SqlCommand cmd = new SqlCommand(query, conn);
               
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];
                    dataGridView1.DataSource = dt;
                    dataGridView1.Refresh();

                    idbox.Text = "";
                    namebox.Text = "";
                    locationbox.Text = "";
                    searchbox.Text = "";


                



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }





*/