﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class View_Donors : Form
    {
        SqlConnection conn;
        public View_Donors()
        {
            InitializeComponent();
        }
        private void donorlabel_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();

        }
        private void donatelabel_Click(object sender, EventArgs e)
        {
            Donate donate = new Donate();
            donate.Show();
            this.Hide();
        }


        private void patientlabel_Click(object sender, EventArgs e)
        {
            Patient pa = new Patient();
            pa.Show();
            this.Hide();
        }

        private void viewpatientlabel_Click(object sender, EventArgs e)
        {
            View_Patients vp = new View_Patients();
            vp.Show();
            this.Hide();

        }

        private void bloodstocklabel_Click(object sender, EventArgs e)
        {
            Blood_Stock bs = new Blood_Stock();
            bs.Show();
            this.Hide();
        }

        private void bloodtransferlabel_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();

        }

   
        private void logoutlabel_Click(object sender, EventArgs e)
        {
            Login L = new Login();
            L.Show();
            this.Hide();
        }

        private void View_Donors_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();

                string query = "select Id,Name,Age,Gender,Phone,Blood,Address from DonorTB ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                DataGridView1.DataSource = dt;
                DataGridView1.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }

        }

       
        private void searchbox_TextChanged(object sender, EventArgs e)
        {
           
                try
                {
                    conn = new SqlConnection(
                          @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    string query = "select * from DonorTB where name  like '%" + searchbox.Text + "%'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();


                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];
                    DataGridView1.DataSource = dt;
                    DataGridView1.Refresh();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }

        }

       
          
          
    }
}
