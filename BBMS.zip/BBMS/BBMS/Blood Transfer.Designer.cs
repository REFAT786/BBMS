﻿namespace BBMS
{
    partial class Blood_Transfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.idbox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.namebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmlabel = new System.Windows.Forms.Label();
            this.transferbtn = new Guna.UI2.WinForms.Guna2Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.donatelabel = new System.Windows.Forms.Label();
            this.logoutlabel = new System.Windows.Forms.Label();
            this.bloodtransferlabel = new System.Windows.Forms.Label();
            this.bloodstocklabel = new System.Windows.Forms.Label();
            this.viewpatientlabel = new System.Windows.Forms.Label();
            this.patientlabel = new System.Windows.Forms.Label();
            this.viewdonorslabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.donorlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bgbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(594, 73);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(150, 25);
            this.label10.TabIndex = 26;
            this.label10.Text = "Blood Stock ";
            // 
            // idbox
            // 
            this.idbox.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idbox.FormattingEnabled = true;
            this.idbox.Items.AddRange(new object[] {
            "Male ",
            "Female"});
            this.idbox.Location = new System.Drawing.Point(318, 266);
            this.idbox.Margin = new System.Windows.Forms.Padding(2);
            this.idbox.Name = "idbox";
            this.idbox.Size = new System.Drawing.Size(159, 23);
            this.idbox.TabIndex = 40;
            this.idbox.SelectionChangeCommitted += new System.EventHandler(this.idbox_SelectionChangeCommitted);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(322, 217);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 22);
            this.label13.TabIndex = 39;
            this.label13.Text = "Patient Id";
            // 
            // namebox
            // 
            this.namebox.AutoRoundedCorners = true;
            this.namebox.BorderColor = System.Drawing.Color.Red;
            this.namebox.BorderRadius = 13;
            this.namebox.BorderThickness = 2;
            this.namebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namebox.DefaultText = "";
            this.namebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.namebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.namebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.DisabledState.Parent = this.namebox;
            this.namebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.FocusedState.Parent = this.namebox;
            this.namebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.namebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.HoverState.Parent = this.namebox;
            this.namebox.Location = new System.Drawing.Point(574, 259);
            this.namebox.Margin = new System.Windows.Forms.Padding(2);
            this.namebox.Name = "namebox";
            this.namebox.PasswordChar = '\0';
            this.namebox.PlaceholderText = "";
            this.namebox.SelectedText = "";
            this.namebox.ShadowDecoration.Parent = this.namebox;
            this.namebox.Size = new System.Drawing.Size(150, 29);
            this.namebox.TabIndex = 49;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(577, 217);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(138, 22);
            this.label12.TabIndex = 51;
            this.label12.Text = "Patient Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(842, 217);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 22);
            this.label11.TabIndex = 52;
            this.label11.Text = "Blood Group";
            // 
            // cmlabel
            // 
            this.cmlabel.AutoSize = true;
            this.cmlabel.BackColor = System.Drawing.Color.Transparent;
            this.cmlabel.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmlabel.ForeColor = System.Drawing.Color.Red;
            this.cmlabel.Location = new System.Drawing.Point(571, 366);
            this.cmlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.cmlabel.Name = "cmlabel";
            this.cmlabel.Size = new System.Drawing.Size(169, 22);
            this.cmlabel.TabIndex = 53;
            this.cmlabel.Text = "Available Or Not";
            // 
            // transferbtn
            // 
            this.transferbtn.AutoRoundedCorners = true;
            this.transferbtn.BorderRadius = 17;
            this.transferbtn.CheckedState.Parent = this.transferbtn;
            this.transferbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.transferbtn.CustomImages.Parent = this.transferbtn;
            this.transferbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.transferbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.transferbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.transferbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.transferbtn.DisabledState.Parent = this.transferbtn;
            this.transferbtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.transferbtn.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transferbtn.ForeColor = System.Drawing.Color.White;
            this.transferbtn.HoverState.Parent = this.transferbtn;
            this.transferbtn.Location = new System.Drawing.Point(582, 455);
            this.transferbtn.Margin = new System.Windows.Forms.Padding(2);
            this.transferbtn.Name = "transferbtn";
            this.transferbtn.ShadowDecoration.Parent = this.transferbtn;
            this.transferbtn.Size = new System.Drawing.Size(144, 37);
            this.transferbtn.TabIndex = 59;
            this.transferbtn.Text = "Transfer";
            this.transferbtn.Click += new System.EventHandler(this.transferbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.donatelabel);
            this.panel1.Controls.Add(this.logoutlabel);
            this.panel1.Controls.Add(this.bloodtransferlabel);
            this.panel1.Controls.Add(this.bloodstocklabel);
            this.panel1.Controls.Add(this.viewpatientlabel);
            this.panel1.Controls.Add(this.patientlabel);
            this.panel1.Controls.Add(this.viewdonorslabel);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.donorlabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.ForeColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 640);
            this.panel1.TabIndex = 60;
            // 
            // donatelabel
            // 
            this.donatelabel.AutoSize = true;
            this.donatelabel.BackColor = System.Drawing.Color.Transparent;
            this.donatelabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donatelabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donatelabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donatelabel.Location = new System.Drawing.Point(38, 232);
            this.donatelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donatelabel.Name = "donatelabel";
            this.donatelabel.Size = new System.Drawing.Size(90, 25);
            this.donatelabel.TabIndex = 16;
            this.donatelabel.Text = "Donate";
            this.donatelabel.Click += new System.EventHandler(this.donatelabel_Click);
            // 
            // logoutlabel
            // 
            this.logoutlabel.AutoSize = true;
            this.logoutlabel.BackColor = System.Drawing.Color.Transparent;
            this.logoutlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoutlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.logoutlabel.Location = new System.Drawing.Point(59, 605);
            this.logoutlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.logoutlabel.Name = "logoutlabel";
            this.logoutlabel.Size = new System.Drawing.Size(96, 25);
            this.logoutlabel.TabIndex = 15;
            this.logoutlabel.Text = "Log out";
            this.logoutlabel.Click += new System.EventHandler(this.logoutlabel_Click);
            // 
            // bloodtransferlabel
            // 
            this.bloodtransferlabel.AutoSize = true;
            this.bloodtransferlabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodtransferlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodtransferlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodtransferlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodtransferlabel.Location = new System.Drawing.Point(39, 450);
            this.bloodtransferlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodtransferlabel.Name = "bloodtransferlabel";
            this.bloodtransferlabel.Size = new System.Drawing.Size(177, 25);
            this.bloodtransferlabel.TabIndex = 12;
            this.bloodtransferlabel.Text = "Blood Transfer";
            // 
            // bloodstocklabel
            // 
            this.bloodstocklabel.AutoSize = true;
            this.bloodstocklabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodstocklabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodstocklabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodstocklabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodstocklabel.Location = new System.Drawing.Point(39, 397);
            this.bloodstocklabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodstocklabel.Name = "bloodstocklabel";
            this.bloodstocklabel.Size = new System.Drawing.Size(143, 25);
            this.bloodstocklabel.TabIndex = 10;
            this.bloodstocklabel.Text = "Blood Stock";
            this.bloodstocklabel.Click += new System.EventHandler(this.bloodstocklabel_Click);
            // 
            // viewpatientlabel
            // 
            this.viewpatientlabel.AutoSize = true;
            this.viewpatientlabel.BackColor = System.Drawing.Color.Transparent;
            this.viewpatientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewpatientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewpatientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewpatientlabel.Location = new System.Drawing.Point(39, 343);
            this.viewpatientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewpatientlabel.Name = "viewpatientlabel";
            this.viewpatientlabel.Size = new System.Drawing.Size(147, 25);
            this.viewpatientlabel.TabIndex = 8;
            this.viewpatientlabel.Text = "View Patient";
            this.viewpatientlabel.Click += new System.EventHandler(this.viewpatientlabel_Click);
            // 
            // patientlabel
            // 
            this.patientlabel.AutoSize = true;
            this.patientlabel.BackColor = System.Drawing.Color.Transparent;
            this.patientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.patientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.patientlabel.Location = new System.Drawing.Point(39, 288);
            this.patientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.patientlabel.Name = "patientlabel";
            this.patientlabel.Size = new System.Drawing.Size(88, 25);
            this.patientlabel.TabIndex = 6;
            this.patientlabel.Text = "Patient";
            this.patientlabel.Click += new System.EventHandler(this.patientlabel_Click);
            // 
            // viewdonorslabel
            // 
            this.viewdonorslabel.AutoSize = true;
            this.viewdonorslabel.BackColor = System.Drawing.Color.Transparent;
            this.viewdonorslabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewdonorslabel.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewdonorslabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewdonorslabel.Location = new System.Drawing.Point(39, 180);
            this.viewdonorslabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewdonorslabel.Name = "viewdonorslabel";
            this.viewdonorslabel.Size = new System.Drawing.Size(140, 23);
            this.viewdonorslabel.TabIndex = 5;
            this.viewdonorslabel.Text = "View Donors";
            this.viewdonorslabel.Click += new System.EventHandler(this.viewdonorslabel_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.AliceBlue;
            this.panel3.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel3.Location = new System.Drawing.Point(25, 441);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(8, 40);
            this.panel3.TabIndex = 4;
            // 
            // donorlabel
            // 
            this.donorlabel.AutoSize = true;
            this.donorlabel.BackColor = System.Drawing.Color.Transparent;
            this.donorlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donorlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donorlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donorlabel.Location = new System.Drawing.Point(39, 126);
            this.donorlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donorlabel.Name = "donorlabel";
            this.donorlabel.Size = new System.Drawing.Size(81, 25);
            this.donorlabel.TabIndex = 3;
            this.donorlabel.Text = "Donor";
            this.donorlabel.Click += new System.EventHandler(this.donorlabel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(280, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Blood Bank Management System";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(222, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(818, 49);
            this.panel2.TabIndex = 61;
            // 
            // bgbox
            // 
            this.bgbox.AutoRoundedCorners = true;
            this.bgbox.BorderColor = System.Drawing.Color.Red;
            this.bgbox.BorderRadius = 13;
            this.bgbox.BorderThickness = 2;
            this.bgbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bgbox.DefaultText = "";
            this.bgbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.bgbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.bgbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.bgbox.DisabledState.Parent = this.bgbox;
            this.bgbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.bgbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.bgbox.FocusedState.Parent = this.bgbox;
            this.bgbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bgbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.bgbox.HoverState.Parent = this.bgbox;
            this.bgbox.Location = new System.Drawing.Point(838, 259);
            this.bgbox.Margin = new System.Windows.Forms.Padding(2);
            this.bgbox.Name = "bgbox";
            this.bgbox.PasswordChar = '\0';
            this.bgbox.PlaceholderText = "";
            this.bgbox.SelectedText = "";
            this.bgbox.ShadowDecoration.Parent = this.bgbox;
            this.bgbox.Size = new System.Drawing.Size(150, 29);
            this.bgbox.TabIndex = 62;
            // 
            // Blood_Transfer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.bgbox);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.transferbtn);
            this.Controls.Add(this.cmlabel);
            this.Controls.Add(this.namebox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.idbox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label10);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Blood_Transfer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Blood_Transfer";
            this.Load += new System.EventHandler(this.Blood_Transfer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox idbox;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2TextBox namebox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label cmlabel;
        private Guna.UI2.WinForms.Guna2Button transferbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label donatelabel;
        private System.Windows.Forms.Label logoutlabel;
        private System.Windows.Forms.Label bloodtransferlabel;
        private System.Windows.Forms.Label bloodstocklabel;
        private System.Windows.Forms.Label viewpatientlabel;
        private System.Windows.Forms.Label patientlabel;
        private System.Windows.Forms.Label viewdonorslabel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label donorlabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2TextBox bgbox;


    }
}