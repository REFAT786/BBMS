﻿namespace BBMS
{
    partial class View_Donors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label10 = new System.Windows.Forms.Label();
            this.DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.namelabel = new System.Windows.Forms.Label();
            this.searchbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.donatelabel = new System.Windows.Forms.Label();
            this.logoutlabel = new System.Windows.Forms.Label();
            this.bloodtransferlabel = new System.Windows.Forms.Label();
            this.bloodstocklabel = new System.Windows.Forms.Label();
            this.viewpatientlabel = new System.Windows.Forms.Label();
            this.patientlabel = new System.Windows.Forms.Label();
            this.viewdonorslabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.donorlabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(622, 73);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(148, 25);
            this.label10.TabIndex = 17;
            this.label10.Text = "Donors List ";
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridView1.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridView1.EnableHeadersVisualStyles = false;
            this.DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView1.Location = new System.Drawing.Point(235, 186);
            this.DataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersVisible = false;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(794, 408);
            this.DataGridView1.TabIndex = 18;
            this.DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            this.DataGridView1.ThemeStyle.ReadOnly = false;
            this.DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DataGridView1.ThemeStyle.RowsStyle.Height = 24;
            this.DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.BackColor = System.Drawing.Color.Transparent;
            this.namelabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.ForeColor = System.Drawing.Color.Red;
            this.namelabel.Location = new System.Drawing.Point(282, 141);
            this.namelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(74, 25);
            this.namelabel.TabIndex = 35;
            this.namelabel.Text = "Name";
            // 
            // searchbox
            // 
            this.searchbox.AutoRoundedCorners = true;
            this.searchbox.BorderColor = System.Drawing.Color.Red;
            this.searchbox.BorderRadius = 13;
            this.searchbox.BorderThickness = 2;
            this.searchbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchbox.DefaultText = "";
            this.searchbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.searchbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.searchbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.searchbox.DisabledState.Parent = this.searchbox;
            this.searchbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.searchbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.searchbox.FocusedState.Parent = this.searchbox;
            this.searchbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.searchbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.searchbox.HoverState.Parent = this.searchbox;
            this.searchbox.Location = new System.Drawing.Point(370, 139);
            this.searchbox.Margin = new System.Windows.Forms.Padding(2);
            this.searchbox.Name = "searchbox";
            this.searchbox.PasswordChar = '\0';
            this.searchbox.PlaceholderText = "";
            this.searchbox.SelectedText = "";
            this.searchbox.ShadowDecoration.Parent = this.searchbox;
            this.searchbox.Size = new System.Drawing.Size(150, 29);
            this.searchbox.TabIndex = 34;
            this.searchbox.TextChanged += new System.EventHandler(this.searchbox_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.donatelabel);
            this.panel1.Controls.Add(this.logoutlabel);
            this.panel1.Controls.Add(this.bloodtransferlabel);
            this.panel1.Controls.Add(this.bloodstocklabel);
            this.panel1.Controls.Add(this.viewpatientlabel);
            this.panel1.Controls.Add(this.patientlabel);
            this.panel1.Controls.Add(this.viewdonorslabel);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.donorlabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.ForeColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 640);
            this.panel1.TabIndex = 36;
            // 
            // donatelabel
            // 
            this.donatelabel.AutoSize = true;
            this.donatelabel.BackColor = System.Drawing.Color.Transparent;
            this.donatelabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donatelabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donatelabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donatelabel.Location = new System.Drawing.Point(38, 232);
            this.donatelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donatelabel.Name = "donatelabel";
            this.donatelabel.Size = new System.Drawing.Size(90, 25);
            this.donatelabel.TabIndex = 16;
            this.donatelabel.Text = "Donate";
            this.donatelabel.Click += new System.EventHandler(this.donatelabel_Click);
            // 
            // logoutlabel
            // 
            this.logoutlabel.AutoSize = true;
            this.logoutlabel.BackColor = System.Drawing.Color.Transparent;
            this.logoutlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoutlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.logoutlabel.Location = new System.Drawing.Point(59, 605);
            this.logoutlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.logoutlabel.Name = "logoutlabel";
            this.logoutlabel.Size = new System.Drawing.Size(96, 25);
            this.logoutlabel.TabIndex = 15;
            this.logoutlabel.Text = "Log out";
            this.logoutlabel.Click += new System.EventHandler(this.logoutlabel_Click);
            // 
            // bloodtransferlabel
            // 
            this.bloodtransferlabel.AutoSize = true;
            this.bloodtransferlabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodtransferlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodtransferlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodtransferlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodtransferlabel.Location = new System.Drawing.Point(39, 450);
            this.bloodtransferlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodtransferlabel.Name = "bloodtransferlabel";
            this.bloodtransferlabel.Size = new System.Drawing.Size(177, 25);
            this.bloodtransferlabel.TabIndex = 12;
            this.bloodtransferlabel.Text = "Blood Transfer";
            this.bloodtransferlabel.Click += new System.EventHandler(this.bloodtransferlabel_Click);
            // 
            // bloodstocklabel
            // 
            this.bloodstocklabel.AutoSize = true;
            this.bloodstocklabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodstocklabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodstocklabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodstocklabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodstocklabel.Location = new System.Drawing.Point(39, 397);
            this.bloodstocklabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodstocklabel.Name = "bloodstocklabel";
            this.bloodstocklabel.Size = new System.Drawing.Size(143, 25);
            this.bloodstocklabel.TabIndex = 10;
            this.bloodstocklabel.Text = "Blood Stock";
            this.bloodstocklabel.Click += new System.EventHandler(this.bloodstocklabel_Click);
            // 
            // viewpatientlabel
            // 
            this.viewpatientlabel.AutoSize = true;
            this.viewpatientlabel.BackColor = System.Drawing.Color.Transparent;
            this.viewpatientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewpatientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewpatientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewpatientlabel.Location = new System.Drawing.Point(39, 343);
            this.viewpatientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewpatientlabel.Name = "viewpatientlabel";
            this.viewpatientlabel.Size = new System.Drawing.Size(147, 25);
            this.viewpatientlabel.TabIndex = 8;
            this.viewpatientlabel.Text = "View Patient";
            this.viewpatientlabel.Click += new System.EventHandler(this.viewpatientlabel_Click);
            // 
            // patientlabel
            // 
            this.patientlabel.AutoSize = true;
            this.patientlabel.BackColor = System.Drawing.Color.Transparent;
            this.patientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.patientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.patientlabel.Location = new System.Drawing.Point(39, 288);
            this.patientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.patientlabel.Name = "patientlabel";
            this.patientlabel.Size = new System.Drawing.Size(88, 25);
            this.patientlabel.TabIndex = 6;
            this.patientlabel.Text = "Patient";
            this.patientlabel.Click += new System.EventHandler(this.patientlabel_Click);
            // 
            // viewdonorslabel
            // 
            this.viewdonorslabel.AutoSize = true;
            this.viewdonorslabel.BackColor = System.Drawing.Color.Transparent;
            this.viewdonorslabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewdonorslabel.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewdonorslabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewdonorslabel.Location = new System.Drawing.Point(39, 180);
            this.viewdonorslabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewdonorslabel.Name = "viewdonorslabel";
            this.viewdonorslabel.Size = new System.Drawing.Size(140, 23);
            this.viewdonorslabel.TabIndex = 5;
            this.viewdonorslabel.Text = "View Donors";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.AliceBlue;
            this.panel3.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel3.Location = new System.Drawing.Point(25, 168);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(8, 40);
            this.panel3.TabIndex = 4;
            // 
            // donorlabel
            // 
            this.donorlabel.AutoSize = true;
            this.donorlabel.BackColor = System.Drawing.Color.Transparent;
            this.donorlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donorlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donorlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donorlabel.Location = new System.Drawing.Point(39, 126);
            this.donorlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donorlabel.Name = "donorlabel";
            this.donorlabel.Size = new System.Drawing.Size(81, 25);
            this.donorlabel.TabIndex = 3;
            this.donorlabel.Text = "Donor";
            this.donorlabel.Click += new System.EventHandler(this.donorlabel_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(222, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(818, 49);
            this.panel2.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(280, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Blood Bank Management System";
            // 
            // View_Donors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.namelabel);
            this.Controls.Add(this.searchbox);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.label10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "View_Donors";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View_Donors";
            this.Load += new System.EventHandler(this.View_Donors_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridView1;
        private System.Windows.Forms.Label namelabel;
        private Guna.UI2.WinForms.Guna2TextBox searchbox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label donatelabel;
        private System.Windows.Forms.Label logoutlabel;
        private System.Windows.Forms.Label bloodtransferlabel;
        private System.Windows.Forms.Label bloodstocklabel;
        private System.Windows.Forms.Label viewpatientlabel;
        private System.Windows.Forms.Label patientlabel;
        private System.Windows.Forms.Label viewdonorslabel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label donorlabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;

    }
}