﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            if (passwordbox.Text == "")
            {
                MessageBox.Show("please enter password");
            }
            else if (passwordbox.Text == "1234")
            {
                Employees emp = new Employees();
                emp.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("wrong password");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Login L = new Login();
            L.Show();
            this.Hide();
        }
    }
}
