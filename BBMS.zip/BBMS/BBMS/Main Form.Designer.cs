﻿namespace BBMS
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.logoutlabel = new System.Windows.Forms.Label();
            this.bloodtransferlabel = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.bloodstocklabel = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.viewpatientlabel = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.patientlabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.viewdonorlabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.donorlabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(222, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(818, 49);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(280, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Blood Bank Management System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.logoutlabel);
            this.panel1.Controls.Add(this.bloodtransferlabel);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.bloodstocklabel);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.viewpatientlabel);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.patientlabel);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.viewdonorlabel);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.donorlabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.ForeColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 640);
            this.panel1.TabIndex = 0;
            // 
            // logoutlabel
            // 
            this.logoutlabel.AutoSize = true;
            this.logoutlabel.BackColor = System.Drawing.Color.Transparent;
            this.logoutlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoutlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.logoutlabel.Location = new System.Drawing.Point(59, 605);
            this.logoutlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.logoutlabel.Name = "logoutlabel";
            this.logoutlabel.Size = new System.Drawing.Size(89, 25);
            this.logoutlabel.TabIndex = 15;
            this.logoutlabel.Text = "Logout";
            this.logoutlabel.Click += new System.EventHandler(this.logoutlabel_Click);
            // 
            // bloodtransferlabel
            // 
            this.bloodtransferlabel.AutoSize = true;
            this.bloodtransferlabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodtransferlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodtransferlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodtransferlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodtransferlabel.Location = new System.Drawing.Point(39, 399);
            this.bloodtransferlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodtransferlabel.Name = "bloodtransferlabel";
            this.bloodtransferlabel.Size = new System.Drawing.Size(177, 25);
            this.bloodtransferlabel.TabIndex = 12;
            this.bloodtransferlabel.Text = "Blood Transfer";
            this.bloodtransferlabel.Click += new System.EventHandler(this.bloodtransferlabel_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel8.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel8.Location = new System.Drawing.Point(25, 389);
            this.panel8.Margin = new System.Windows.Forms.Padding(2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(8, 40);
            this.panel8.TabIndex = 11;
            // 
            // bloodstocklabel
            // 
            this.bloodstocklabel.AutoSize = true;
            this.bloodstocklabel.BackColor = System.Drawing.Color.Transparent;
            this.bloodstocklabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bloodstocklabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodstocklabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bloodstocklabel.Location = new System.Drawing.Point(39, 346);
            this.bloodstocklabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bloodstocklabel.Name = "bloodstocklabel";
            this.bloodstocklabel.Size = new System.Drawing.Size(143, 25);
            this.bloodstocklabel.TabIndex = 10;
            this.bloodstocklabel.Text = "Blood Stock";
            this.bloodstocklabel.Click += new System.EventHandler(this.bloodstocklabel_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel7.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel7.Location = new System.Drawing.Point(25, 336);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(8, 40);
            this.panel7.TabIndex = 9;
            // 
            // viewpatientlabel
            // 
            this.viewpatientlabel.AutoSize = true;
            this.viewpatientlabel.BackColor = System.Drawing.Color.Transparent;
            this.viewpatientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewpatientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewpatientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewpatientlabel.Location = new System.Drawing.Point(39, 292);
            this.viewpatientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewpatientlabel.Name = "viewpatientlabel";
            this.viewpatientlabel.Size = new System.Drawing.Size(147, 25);
            this.viewpatientlabel.TabIndex = 8;
            this.viewpatientlabel.Text = "View Patient";
            this.viewpatientlabel.Click += new System.EventHandler(this.viewpatientlabel_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel6.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel6.Location = new System.Drawing.Point(25, 283);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(8, 40);
            this.panel6.TabIndex = 7;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel5.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel5.Location = new System.Drawing.Point(25, 228);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(8, 40);
            this.panel5.TabIndex = 6;
            // 
            // patientlabel
            // 
            this.patientlabel.AutoSize = true;
            this.patientlabel.BackColor = System.Drawing.Color.Transparent;
            this.patientlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.patientlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.patientlabel.Location = new System.Drawing.Point(39, 237);
            this.patientlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.patientlabel.Name = "patientlabel";
            this.patientlabel.Size = new System.Drawing.Size(88, 25);
            this.patientlabel.TabIndex = 6;
            this.patientlabel.Text = "Patient";
            this.patientlabel.Click += new System.EventHandler(this.patientlabel_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel4.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel4.Location = new System.Drawing.Point(25, 171);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(8, 40);
            this.panel4.TabIndex = 5;
            // 
            // viewdonorlabel
            // 
            this.viewdonorlabel.AutoSize = true;
            this.viewdonorlabel.BackColor = System.Drawing.Color.Transparent;
            this.viewdonorlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewdonorlabel.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewdonorlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.viewdonorlabel.Location = new System.Drawing.Point(39, 182);
            this.viewdonorlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.viewdonorlabel.Name = "viewdonorlabel";
            this.viewdonorlabel.Size = new System.Drawing.Size(140, 23);
            this.viewdonorlabel.TabIndex = 5;
            this.viewdonorlabel.Text = "View Donors";
            this.viewdonorlabel.Click += new System.EventHandler(this.viewdonorslabel_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel3.ForeColor = System.Drawing.Color.BlueViolet;
            this.panel3.Location = new System.Drawing.Point(25, 115);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(8, 40);
            this.panel3.TabIndex = 4;
            // 
            // donorlabel
            // 
            this.donorlabel.AutoSize = true;
            this.donorlabel.BackColor = System.Drawing.Color.Transparent;
            this.donorlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.donorlabel.Font = new System.Drawing.Font("Lucida Fax", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donorlabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.donorlabel.Location = new System.Drawing.Point(39, 126);
            this.donorlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.donorlabel.Name = "donorlabel";
            this.donorlabel.Size = new System.Drawing.Size(81, 25);
            this.donorlabel.TabIndex = 3;
            this.donorlabel.Text = "Donor";
            this.donorlabel.Click += new System.EventHandler(this.donorlabel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(222, 49);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(931, 619);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Main_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main_Form";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label viewdonorlabel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label donorlabel;
        private System.Windows.Forms.Label patientlabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label viewpatientlabel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label logoutlabel;
        private System.Windows.Forms.Label bloodtransferlabel;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label bloodstocklabel;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}