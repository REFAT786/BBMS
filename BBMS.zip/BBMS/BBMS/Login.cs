﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Login : Form
    {
        SqlConnection conn;
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

     
        
        private void adminlabel_Click(object sender, EventArgs e)
        {
            Admin ad = new Admin();
            ad.Show();
            this.Hide();

        }
        private void loginbtn_Click(object sender, EventArgs e)
        {

            conn = new SqlConnection(
                     @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

            conn.Open();
            string query = "select count(*) from EmployeeTB where Name='" + namebox.Text + "' and Password='" + passwordbox.Text + "' ";
            SqlCommand cmd = new SqlCommand(query,conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);
            string a = dt.Rows[0][0].ToString();
            if (a == "1")
            {

                Main_Form m = new Main_Form();
                m.Show();
                this.Hide();
                conn.Close();

            }
            else
            {
                MessageBox.Show("wroung username or password");
            }
            conn.Close();


        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
