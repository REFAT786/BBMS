﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Blood_Transfer : Form
    {
        int stock;
        SqlConnection conn;
        public Blood_Transfer()
        {
            InitializeComponent();
            fillPatientCB();
        }

        private void donorlabel_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();

        }
        private void viewdonorslabel_Click(object sender, EventArgs e)
        {
            View_Donors vd = new View_Donors();
            vd.Show();
            this.Hide();

        }
        private void donatelabel_Click(object sender, EventArgs e)
        {
            Donate donate = new Donate();
            donate.Show();
            this.Hide();
        }


        private void patientlabel_Click(object sender, EventArgs e)
        {
            Patient pa = new Patient();
            pa.Show();
            this.Hide();
        }
        private void viewpatientlabel_Click(object sender, EventArgs e)
        {
            View_Patients vp = new View_Patients();
            vp.Show();
            this.Hide();

        }



        private void bloodstocklabel_Click(object sender, EventArgs e)
        {
            Blood_Stock bs = new Blood_Stock();
            bs.Show();
            this.Hide();
        }




        private void logoutlabel_Click(object sender, EventArgs e)
        {
            Login L = new Login();
            L.Show();
            this.Hide();
        }

        
        private void fillPatientCB()
        {
            conn = new SqlConnection(
               @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

            conn.Open();


            SqlCommand cmd = new SqlCommand("select Id from PatientTB ", conn);
            SqlDataReader da;
            da = cmd.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Columns.Add("Id",typeof(int));
            dt.Load(da);

            idbox.ValueMember = "Id";
            idbox.DataSource = dt;
            conn.Close();
        }
        private void GetData()  
        {

            conn = new SqlConnection(
            @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

            conn.Open();

            string query = "select * from PatientTB where Id='" + idbox.SelectedValue.ToString() + "'";

            SqlCommand cmd = new SqlCommand(query, conn);
            
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                namebox.Text=dr["Name"].ToString();
                bgbox.Text = dr["Blood"].ToString();
            }
            conn.Close();

        }
        private void GetStock(string bgbox)//for 1st stock  
        {

            conn = new SqlConnection(
            @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

            conn.Open();

            string query = "select Blood,Stock from StockTB where Blood='" + bgbox + "'";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                stock = Convert.ToInt32(dr["Stock"].ToString());

            }

        }

      

        private void idbox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            
              GetData();
             GetStock(bgbox.Text);
            if (stock > 0)
             {
                 transferbtn.Visible = true;
                 cmlabel.Text = "Available Stock";
                 cmlabel.Visible = true;

             }
             else 
             {
                 cmlabel.Text = "Stock not Available";
                 cmlabel.Visible = true;
                 transferbtn.Visible = false;
             } 
              
        }
      

        private void BStock()//for update stock
        {

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();
                GetStock(bgbox.Text);
                stock = stock - 1;
                string query = "update StockTB set  Stock='" + stock + "' where Blood='" + bgbox.Text + "'  ";

                SqlCommand cmd = new SqlCommand(query, conn);
                int row=cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    // MessageBox.Show("update successful");
                    query = "select Blood,Stock from StockTB ";

                    cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }


        }
        private void Blood_Transfer_Load(object sender, EventArgs e)
        {

        }
        private void transferbtn_Click(object sender, EventArgs e)
        {


            string name,bg;
            int id;

            id = Convert.ToInt32(idbox.Text);
            name = namebox.Text;
            bg = bgbox.Text.ToString();

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();
                string query = "insert into TransferTB (PatientID,Name,Blood) values('"+id+"','" + name + "','" + bg + "')";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Blood transfer successful");
                BStock();
                idbox.Text = "";
                namebox.Text = "";
                bgbox.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }


        }

        
    }
}
