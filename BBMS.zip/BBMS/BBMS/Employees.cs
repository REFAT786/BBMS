﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Employees : Form
    {
        SqlConnection conn;
        public Employees()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Employees_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();

                string query = "select *from EmployeeTB ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                DataGridView1.DataSource = dt;
                DataGridView1.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    conn = new SqlConnection(
                         @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    int dataid = Convert.ToInt32(DataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                    string query = "select * from EmployeeTB where Id='" + dataid + "' ";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    DataTable dt = ds.Tables[0];

                    idbox.Text = dt.Rows[0]["Id"].ToString();
                    namebox.Text = dt.Rows[0]["Name"].ToString();
                    passwordbox.Text = dt.Rows[0]["Password"].ToString();
                    


                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }

        private void addbtn_Click(object sender, EventArgs e)
        {

            string name;
            int password; 

            name = namebox.Text;
            password = Convert.ToInt32(passwordbox.Text); 
            

            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();
                string query = "insert into EmployeeTB (Name,Password) values('" + name + "','" + password + "')";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();

                MessageBox.Show(" Add successfully");

                query = "select * from EmployeeTB ";

                cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataTable dt = ds.Tables[0];
                DataGridView1.DataSource = dt;
                DataGridView1.Refresh();


                idbox.Text = "";
                namebox.Text = "";
                passwordbox.Text = "";
                
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }

        private void editbtn_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(
                @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                conn.Open();

                string name = namebox.Text;
                int pass = Convert.ToInt32(passwordbox.Text);
                string query = "update EmployeeTB set  Name='" + name + "',Password='" + pass + "' where Id='" + idbox.Text + "'  ";


                SqlCommand cmd = new SqlCommand(query, conn);
                int row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    MessageBox.Show("Edit successful");
                    query = "select * from EmployeeTB ";

                    cmd = new SqlCommand(query, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = ds.Tables[0];
                    DataGridView1.DataSource = dt;
                    DataGridView1.Refresh();

                    idbox.Text="";
                    namebox.Text = "";
                    passwordbox.Text = "";
                    


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();

            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (idbox.Text == "")
            {
                MessageBox.Show("please select a row first");

            }
            else
            {
                try
                {
                    conn = new SqlConnection(
                    @"Data Source=DESKTOP-8O60JH4\SQLEXPRESS;Initial Catalog=BBMS_DB;Integrated Security=True");

                    conn.Open();

                    string query = "delete from EmployeeTB where Id= " + idbox.Text;
                    SqlCommand cmd = new SqlCommand(query, conn);
                    int row = cmd.ExecuteNonQuery();

                    if (row > 0)
                    {
                        MessageBox.Show("Delete successful");
                        query = "select * from EmployeeTB ";

                        cmd = new SqlCommand(query, conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        DataTable dt = ds.Tables[0];
                        DataGridView1.DataSource = dt;
                        DataGridView1.Refresh();

                        idbox.Text = "";
                        namebox.Text = "";
                        passwordbox.Text = "";



                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();

                }
            }
        }

        private void logoutlabel_Click(object sender, EventArgs e)
        {
        
            Login L = new Login();
            L.Show();
            this.Hide();
       

        }
    }
}
