﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }
        private void donorlabel_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();

        }

        private void viewdonorslabel_Click(object sender, EventArgs e)
        {
            View_Donors vd = new View_Donors();
            vd.Show();
            this.Hide();

        }
        private void donatelabel_Click(object sender, EventArgs e)
        {
            Donate donate = new Donate();
            donate.Show();
            this.Hide();
        }


        private void patientlabel_Click(object sender, EventArgs e)
        {
            Patient pa = new Patient();
            pa.Show();
            this.Hide();
        }

        private void viewpatientlabel_Click(object sender, EventArgs e)
        {
            View_Patients vp = new View_Patients();
            vp.Show();
            this.Hide();

        }

        private void bloodstocklabel_Click(object sender, EventArgs e)
        {
            Blood_Stock bs = new Blood_Stock();
            bs.Show();
            this.Hide();
        }

        private void bloodtransferlabel_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();

        }

      

        private void logoutlabel_Click(object sender, EventArgs e)
        {
            Login L = new Login();
            L.Show();
            this.Hide();
        }

        
    }
}
